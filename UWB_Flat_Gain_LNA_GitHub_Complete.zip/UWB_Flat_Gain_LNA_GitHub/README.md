# UWB Flat-Gain Low Noise Amplifier (LNA)

## Project Overview

This project presents the design and simulation of a **flat-gain 90 nm CMOS Ultra-Wideband (UWB) Low Noise Amplifier**. The project material describes a two-stage cascoded architecture using resistive/inductive degeneration and feedback techniques to obtain wideband gain, low noise, linearity and stability.

The project also investigates an **ultra-low-power, inductorless LNA approach** for IoT edge devices, using active shunt feedback, current reuse and noise-cancelling techniques.

## Reported Design Targets / Results

According to the project presentation:

- **Technology:** 90 nm CMOS for the UWB flat-gain LNA; the presentation also reports CMOS 180 nm depending on implementation for the ultra-low-power design.
- **UWB operating range:** 12–15 GHz
- **Gain:** approximately 15 ± 1 dB
- **Noise Figure:** approximately 2–4 dB
- **Supply:** approximately 1.2 V for the reported UWB design
- **Power:** approximately 15 mW
- **Input matching:** target S11 below −10 dB over a wide frequency range
- **Architecture:** two-stage cascoded LNA with feedback and degeneration

## Design Objectives

- Achieve a relatively flat gain across the UWB frequency range.
- Maintain a low noise figure.
- Improve stability and linearity.
- Reduce power consumption.
- Explore inductorless implementation for compact IoT/RF front ends.
- Use active shunt feedback for gain control and input-impedance matching.

## Main Techniques

### Cascoded Architecture
The cascoded stages provide gain and improve isolation between circuit nodes.

### Feedback
Active shunt feedback is used to provide tunability of gain, bandwidth and input impedance without relying entirely on bulky passive inductors.

### Bias and Transistor Sizing
Bias conditions and transistor dimensions are optimized to balance gain, noise, bandwidth and power.

### Current Reuse and Noise Cancellation
The ultra-low-power concept uses current reuse and noise-cancelling techniques to obtain higher gain with reduced power.

## Tools

- Cadence Virtuoso
- LTspice

## Simulation Parameters

The design can be evaluated using:

- DC operating-point analysis
- AC/frequency sweep
- Gain / S21
- Noise figure
- Input matching / S11
- Stability
- Power consumption
- Transient response

## Project Files

```text
UWB_Flat_Gain_LNA/
├── README.md
├── ULPLNA.png
├── UWB_Flat_Gain_LNA_Presentation.pptx
└── images/
    └── extracted presentation figures
```

## Schematic

![Cadence Virtuoso LNA Schematic](ULPLNA.png)

## Applications

- UWB receivers
- IoT edge devices
- RF front-end circuits
- Radar systems
- Wireless communication
- Wearable and biomedical wireless systems

## Future Scope

The project presentation identifies possible extensions including SoC integration, multi-band IoT operation, ultra-low-power biomedical systems, adaptive feedback networks, machine-learning-assisted RF optimization and further noise reduction.

## Team

- N. Rithvika — 2300040105
- B. Srinivas — 2300040090
- D. Chandrasekhar — 2300040082
